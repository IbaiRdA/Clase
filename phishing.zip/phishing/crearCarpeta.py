import os
# Definir el nombre de la carpeta
folder = "mini_dataset"
# Crear la carpeta si no existe
if not os.path.exists(folder):
    os.mkdir(folder)